package com.capgemini.hibernate.controller;

import java.util.Scanner;

import com.capgemini.hibernate.beans.UserBean;
import com.capgemini.hibernate.dao.UserDao;
import com.capgemini.hibernate.factory.Factory;
import com.capgemini.hibernate.validation.ValidationDao;

public class UserRegistration {
	public static void registration() {
		UserDao dao = Factory.getUserDAOImplInstance();
		Scanner scan = new Scanner(System.in);
		ValidationDao vali = Factory.getValImplInstance();
		UserBean userBean = new UserBean();
		System.out.println("ENTER THE EMAILID");
		String b = scan.nextLine();
		if (vali.validationEmail(b)) {
			userBean.setEmailId(b);
			System.out.println("ENTER THE PASSWORD");
			String c = scan.nextLine();
			if (vali.validationPassword(c)) {
				userBean.setPassword(c);
				System.out.println("ENTER THE MOBILE NUMBER");
				String u=scan.nextLine();
				if (vali.validationMobileNo(u)) {
					userBean.setMobileNo(u);
				 dao.registration(b, c ,u);
					
				}else {
					System.out.println("ENTER VALID MOBILENO");
				}
			}else {
					System.out.println("ENTER VALID PASSWORD");
				}
		}else {
					System.out.println("ENTER VALID NAME");
				}
			

	}

}
