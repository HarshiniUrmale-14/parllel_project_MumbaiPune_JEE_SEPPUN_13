package com.capgemini.hibernate.dao;

public interface UserDao {
	public int userLogin(String emailId, String password);

	public void registration(String emailId, String password,String mobileNo);

	public void updateUser(int uId);

	public void addToCart(int uId);

	public void payment(int uId);

	public void deleteFromCart(String pName);

	public void sendRequest(int uId);

	public void seeReply(int uId);

}