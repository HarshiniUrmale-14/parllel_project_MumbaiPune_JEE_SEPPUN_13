package com.capgemini.hibernate.controller;

import java.util.List;
import java.util.Scanner;

import com.capgemini.hibernate.beans.AdminBean;
import com.capgemini.hibernate.beans.ProductBean;
import com.capgemini.hibernate.dao.AdminDao;
import com.capgemini.hibernate.dao.Dao;
import com.capgemini.hibernate.factory.Factory;

public class AdminTest {
	public static void admin() {
		Dao dao1 = Factory.getDAOImplInstance();
		AdminDao dao = Factory.getAdminDAOImplInstance();
		Scanner scan = new Scanner(System.in);
		System.out.println("ENTER THE EMAIL");
		String b = scan.nextLine();
		System.out.println("ENTER THE PASSWORD");
		String c = scan.nextLine();
		AdminBean s = dao.adminLogin(b, c);
		while (s != null) {
			System.out.println("ENTER 1 TO VIEW THE PRODUCT ");
			System.out.println("ENTER 2 TO ADD THE PRODUCT ");
			System.out.println("ENTER 3 TO UPDATE THE PRODUCT ");
			System.out.println("ENTER 4 TO DELETE THE PRODUCT ");
			System.out.println("ENTER 5 TO DELETE THE USER");
			System.out.println("ENTER 6 TO SEE THE MESSAGE FROM USER");
			System.out.println("ENTER 7 TO GIVE REPLY TO USER");
			System.out.println("ENTER 8 TO LOGOUT");
			int btn = Integer.parseInt(scan.nextLine());
			switch (btn) {
			case 1: {
				System.out.println("HERE ARE THE PRODUCTS");
				List<ProductBean> list = dao1.getProducts();
				if (list != null) {
					for (ProductBean user : list) {
						System.out.println(user.getpId());
						System.out.println(user.getpCategory());
						System.out.println(user.getpName());
						System.out.println(user.getpPrice());
						System.out.println(user.getpQuantity());
						
					}
				} else {
					System.out.println("SOMETHING WENT WRONG");

				}
				break;
			}
			case 2: {
				System.out.println("ENTER THE NUMBER OF PRODUCTS TO BE INSERTED");
				int count = Integer.parseInt(scan.nextLine());
				for (int i = 1; i <= count; i++) {
					System.out.println(" ENTER THE PRODUCT CATEGORY");
					String category = scan.nextLine();
					System.out.println("ENTER THE PRODUCT ID ");
					int id = Integer.parseInt(scan.nextLine());
					System.out.println("ENTER THE PRODUCT NAME ");
					String name = scan.nextLine();
					System.out.println("ENTER THE PRODUCT PRICE ");
					Double price = Double.parseDouble(scan.nextLine());
					System.out.println("ENTER THE PRODUCT QUANTITY AVAILABLE");
					int quantity = Integer.parseInt(scan.nextLine());

					dao.insertProduct(category, id, name, price, quantity);
				}

				break;

			}

			case 3: {
				System.out.println("ENTER THE ID OF PRODUCT TO BE UPDATED");
				int id = Integer.parseInt(scan.nextLine());

				dao.updateProduct(id);

				break;
			} // end of case 3

			case 4: {
				System.out.println("ENTER THE PRODUCT ID ");
				int id = Integer.parseInt(scan.nextLine());
				dao.deleteProduct(id);

				break;
			} // end of case 4
			case 5: {
				System.out.println("ENTER THE ID OF USER TO BE DELETED");
				int id = Integer.parseInt(scan.nextLine());
				dao.deleteUser(id);

				break;
			}
			case 6: {
				dao.seeRequest();
				break;
			}
			case 7: {
				dao.sendReply();
				break;
			}

			case 8: {
				System.out.println("YOU ARE LOGGED OUT");
				System.exit(0);
				break;
			}
			}

		}
	}
}
