package com.capgemini.hibernate.controller;

import java.util.List;
import java.util.Scanner;

import com.capgemini.hibernate.beans.ProductBean;
import com.capgemini.hibernate.beans.UserBean;
import com.capgemini.hibernate.dao.Dao;
import com.capgemini.hibernate.dao.UserDao;
import com.capgemini.hibernate.factory.Factory;
import com.capgemini.hibernate.validation.ValidationDao;

public class UserTest {
	public static void user() {

		Scanner scan = new Scanner(System.in);
		Dao dao1 = Factory.getDAOImplInstance();
		UserDao dao = Factory.getUserDAOImplInstance();
		ValidationDao vali = Factory.getValImplInstance();
		UserBean userBean = new UserBean();
		System.out.println("ENTER THE EMAIL");
		String m = scan.nextLine();

		System.out.println("ENTER THE PASSWORD");
		String c = scan.nextLine();

		int s = dao.userLogin(m, c);
		while (s != 0) {
			System.out.println("ENTER 1 TO VIEW THE PRODUCTS");
			System.out.println("ENTER 2 TO ADD PRODUCT TO THE CART");
			System.out.println("ENTER 3 TO UPDATE THE PROFILE OF USER");
			System.out.println("ENTER 4 TO DELETE PRODUCTS FORM CART");
			System.out.println("ENTER 5 TO MAKE PAYMENT");
			System.out.println("ENTER 6 TO SEND THE MESSAGE TO ADMINISTRATOR");
			System.out.println("ENTER 7 TO SEE THE REPLY FROM ADMINISTRATOR");
			System.out.println("ENTER 8 TO LOGOUT");
			int btn = Integer.parseInt(scan.nextLine());
			switch (btn) {
			case 1: {
				List<ProductBean> list = dao1.getProducts();
				if (list != null) {
					for (ProductBean user : list) {
						System.out.println(user.getpId());
						System.out.println(user.getpCategory());
						System.out.println(user.getpName());
						System.out.println(user.getpPrice());
						System.out.println(user.getpQuantity());
					}
				} else {
					System.out.println("SOMETHING WENT WRONG");
				}
				break;
			}

			case 2: {
				System.out.println("ADD THE PRODUCTS TO THE CART");
				dao.addToCart(s);

				System.out.println("ENTER 1 TO DELETE PRODUCT FROM THE CART");
				System.out.println("ENTER 2 TO MAKE PAYMENT");
				int bt = Integer.parseInt(scan.nextLine());
				if (bt == 1) {
					System.out.println("ENTER THE PRODUCT NAME TO BE DELETED");
					String e = scan.nextLine();
					dao.deleteFromCart(e);

				} else {
					System.out.println("YOUR PAYMENT IS");
					dao.payment(s);
				}

				break;
			}
			case 3: {
				System.out.println("UPDATE THE PROFILE");
				dao.updateUser(s);
				break;
			}

			case 4: {
				System.out.println("ENTER THE PRODUCT NAME TO BE DELETED");
				String e = scan.nextLine();
				dao.deleteFromCart(e);
			}
			case 5: {
				dao.payment(s);
				break;
			}

			case 6: {

				dao.sendRequest(s);
				break;

			}
			case 7: {

				dao.seeReply(s);
				break;

			}
			case 8: {
				System.out.println("YOU ARE LOGGED OUT");
				System.exit(0);
				break;
			}

			}

		}
	}
}
