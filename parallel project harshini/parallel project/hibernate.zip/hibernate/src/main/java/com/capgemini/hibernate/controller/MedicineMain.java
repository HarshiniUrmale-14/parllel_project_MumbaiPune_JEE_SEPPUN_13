package com.capgemini.hibernate.controller;

import java.util.Scanner;

import com.capgemini.hibernate.dao.Dao;
import com.capgemini.hibernate.factory.Factory;



public class MedicineMain {

	public static void main(String[] args) {
	
		Scanner scan = new Scanner(System.in);
		while(true) {
		System.out.println("PRESS 0 TO VIEW THE PRODUCTS");
		System.out.println("PRESS 1 TO LOGIN AS ADMINISTRATOR");
		System.out.println("PRESS 2 TO LOGIN AS USER");
		System.out.println("press 3 TO FOR REGISTATION FOR USER ");

		int button = Integer.parseInt(scan.nextLine());
		switch (button) {
		case 0: {
			System.out.println("HERE ARE THE PRODUCTS");
			ProductTest.product();
			break;
		}
		case 1: {
			System.out.println("WELCOME TO LOGIN AS ADMINISTRATOR");
			AdminTest.admin();
			break;
		}
		case 2: {
			System.out.println("WELCOME TO LOGIN AS USER");
			UserTest.user();
			break;
		}
		case 3: {
			System.out.println("WELCOME TO REGISTRATION PAGE");
			UserRegistration.registration();
			break;

		}
		}
	}
	}

}
