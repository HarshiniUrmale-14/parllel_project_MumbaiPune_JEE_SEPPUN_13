package com.capgemini.hibernate.dao;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.capgemini.hibernate.beans.AdminBean;
import com.capgemini.hibernate.beans.ProductBean;
import com.capgemini.hibernate.beans.ReplyBean;
import com.capgemini.hibernate.beans.RequestBean;
import com.capgemini.hibernate.beans.UserBean;

public class AdminDaoImpl implements AdminDao {

	@Override
	public AdminBean adminLogin(String emailId, String password) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("medicine");
		EntityManager manager = emf.createEntityManager();
		String jpql = "from AdminBean where emailId=:emailId and password=:password";
		Query query = manager.createQuery(jpql);
		query.setParameter("emailId", emailId);
		query.setParameter("password", password);
		AdminBean bean = null;
		try {
			bean = (AdminBean) query.getSingleResult();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return bean;
	}

	@Override
	public void insertProduct(String pCategory, int pId, String pName, Double pPrice, int pQuantity) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("medicine");
		EntityManager manager = emf.createEntityManager();

		EntityTransaction tx = manager.getTransaction();

		ProductBean product = new ProductBean();
		product.setpCategory(pCategory);
		product.setpId(pId);
		product.setpName(pName);
		product.setpPrice(pPrice);
		product.setpQuantity(pQuantity);
		tx.begin();
		manager.persist(product);
		tx.commit();
		if (product != null) {
			System.out.println("PRODUCT INSERTED");
		}

	}

	@Override
	public void deleteProduct(int pId) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("medicine");

		EntityManager entityManager = emf.createEntityManager();
		boolean isDeleted = false;

		try {
			EntityTransaction tx = entityManager.getTransaction();
			tx.begin();
			ProductBean bean = entityManager.find(ProductBean.class, pId);
			entityManager.remove(bean);
			tx.commit();
			isDeleted = true;
			if (isDeleted = true) {
				System.out.println("PRODUCT DELETED");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		entityManager.close();

	}

	@Override
	public void updateProduct(int pId) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("medicine");
		EntityManager manager = emf.createEntityManager();
		EntityTransaction tran = manager.getTransaction();

		Scanner sc = new Scanner(System.in);

		System.out.println("");
		System.out.println("ENTER THE CATEGORY OF PRODUCT");
		String categor = sc.nextLine();
		System.out.println("ENTER THE PRODUCT NAME");
		String name = sc.nextLine();
		System.out.println("ENTER THE PRICE OF THE PRODUCT");
		double price = Double.parseDouble(sc.nextLine());
		System.out.println("ENTER THE QUANTITY OF THE PRODUCT PRESENT");
		int quant = Integer.parseInt(sc.nextLine());

		tran.begin();
		ProductBean bean = manager.find(ProductBean.class, pId);
		bean.setpCategory(categor);
		bean.setpName(name);
		bean.setpPrice(price);
		bean.setpQuantity(quant);
		tran.commit();
		manager.close();

		if (bean != null) {
			System.out.println("PRODUCTS UPDATED");
		}

	}

	@Override
	public void deleteUser(int uId) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("medicine");
		EntityManager entityManager = emf.createEntityManager();
		boolean isDeleted = false;

		try {
			EntityTransaction tx = entityManager.getTransaction();
			tx.begin();
			UserBean bean = entityManager.find(UserBean.class, uId);
			entityManager.remove(bean);
			tx.commit();
			isDeleted = true;
			if (isDeleted = true) {
				System.out.println("USER DELETED");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		entityManager.close();

	}

	@Override
	public void sendReply() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("medicine");
		EntityManager manager = emf.createEntityManager();
		EntityTransaction tx = manager.getTransaction();
		Scanner scan = new Scanner(System.in);
		System.out.println("ENTER THE USER ID");
		int uId = Integer.parseInt(scan.nextLine());
		String emailId = null;
		String msg = null;
		String jpql = " from UserBean  where uId=:uId";
		Query query = manager.createQuery(jpql);
		query.setParameter("uId", uId);
		List<UserBean> list = query.getResultList();
		for (UserBean li : list) {
			emailId = li.getEmailId();

		}

		System.out.println("ENTER THE MESSAGE TO BE SENT");
		msg = scan.nextLine();
		ReplyBean bean = new ReplyBean();
		bean.setuId(uId);
		bean.setEmailId(emailId);
		bean.setMsgReply(msg);
		tx.begin();
		manager.persist(bean);
		tx.commit();
		if (bean != null) {
			System.out.println("MESSAGE SENT SUCCESSFULLY");
		}

	}

	@Override
	public void seeRequest() {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("medicine");
		EntityManager manager = emf.createEntityManager();
		EntityTransaction tx = manager.getTransaction();
		tx.begin();
		String jpql = "from RequestBean";

		Query query = manager.createQuery(jpql);

		List<RequestBean> list = query.getResultList();
		for (RequestBean li : list) {

			System.out.println("USER ID" + li.getuId());
			System.out.println("USER EMAILID" + li.getEmailId());
			System.out.println("MESSAGE FROM USER" + li.getMsgReq());

		}
		tx.commit();
	}
}
