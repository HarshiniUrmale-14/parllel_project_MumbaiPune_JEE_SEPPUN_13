package com.capgemini.hibernate.dao;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.capgemini.hibernate.beans.CartBean;
import com.capgemini.hibernate.beans.ProductBean;
import com.capgemini.hibernate.beans.ReplyBean;
import com.capgemini.hibernate.beans.RequestBean;
import com.capgemini.hibernate.beans.UserBean;

public class UserDaoImpl implements UserDao {

	@Override
	public int userLogin(String emailId, String password) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("medicine");
		EntityManager manager = emf.createEntityManager();
		String jpql = "from UserBean where emailId=:emailId and password=:password";
		Query query = manager.createQuery(jpql);
		query.setParameter("emailId", emailId);
		query.setParameter("password", password);

		List<UserBean> list = query.getResultList();
		for (UserBean li : list) {
			int userId = li.getId();
			System.out.println("welcome" + li.getEmailId());
			return userId;
		}
		return 0;

	}

	@Override
	public void registration(String emailId, String password,String mobileNo) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("medicine");
		EntityManager manager = emf.createEntityManager();

		EntityTransaction tx = manager.getTransaction();
		UserBean bean = new UserBean();
		bean.setEmailId(emailId);
		bean.setPassword(password);
		bean.setMobileNo(mobileNo);

		tx.begin();
		manager.persist(bean);
		if (bean != null) {
			System.out.println(" USER REGISTRATION DONE");
		}
		tx.commit();
	}

	@Override
	public void updateUser(int uId) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("medicine");
		EntityManager manager = emf.createEntityManager();
		EntityTransaction tran = manager.getTransaction();
		Scanner sc = new Scanner(System.in);
		System.out.println("ENTER THE EMAIL ID");
		String emailId = sc.nextLine();
		System.out.println("ENTER THE PASSWORD");
		String password = sc.nextLine();
		System.out.println("ENTER THE MOBILENO");
		String mobileNo= sc.nextLine();

		tran.begin();
		UserBean bean = manager.find(UserBean.class, uId);
		bean.setEmailId(emailId);
		bean.setPassword(password);
		bean.setMobileNo(mobileNo);

		tran.commit();
		manager.close();

		if (bean != null) {
			System.out.println("USER PROFILE UPDATED");
		}
	}

	@Override
	public void addToCart(int uId) {
		String email = null;
		String category = null;
		double price = 0;
		int id = 0;
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("medicine");
		EntityManager manager = emf.createEntityManager();
		EntityTransaction tx = manager.getTransaction();
		String jpql = " from UserBean  where uId=:uId";
		Query query = manager.createQuery(jpql);
		query.setParameter("uId", uId);
		List<UserBean> list = query.getResultList();
		for (UserBean li : list) {
			email = li.getEmailId();

		}
		Scanner scan = new Scanner(System.in);

		System.out.println("ENTER THE NAME OF PRODUCT TO BE ADDED TO THE CART");
		String pName = scan.nextLine();
		String jpql1 = "from ProductBean where pName=:pName";
		Query query1 = manager.createQuery(jpql1);

		query1.setParameter("pName", pName);
		List<ProductBean> list1 = query1.getResultList();
		for (ProductBean li : list1) {
			category = li.getpCategory();
			id = li.getpId();
			pName = li.getpName();
			price = li.getpPrice();

		}
		System.out.println("ENTER THE NO OF QUANTITY OF SELECTED PRODUCT");
		int qua = Integer.parseInt(scan.nextLine());
		CartBean bean = new CartBean();
		bean.setuId(uId);
		bean.setpId(id);
		bean.setEmailId(email);
		bean.setpCategory(category);
		bean.setpName(pName);
		bean.setpPrice(price);
		bean.setQuantity(qua);
		tx.begin();
		manager.persist(bean);
		tx.commit();
		if (bean != null) {
			System.out.println("PRODUCT INSERTED");
		}

	}

	@Override
	public void payment(int uId) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("medicine");

		EntityManager manager = emf.createEntityManager();
		EntityTransaction tx = manager.getTransaction();
		tx.begin();
		String jpql = "select SUM(pPrice*quantity) from CartBean where uId=:uId";

		Query query1 = manager.createQuery(jpql);
		query1.setParameter("uId", uId);

		List<Double> list1 = query1.getResultList();

		for (Double li : list1) {
			double bill = li.doubleValue();
			System.out.println("TOTAL BILL IS" + bill);

		}
		tx.commit();

	}

	@Override
	public void deleteFromCart(String pName) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("medicine");

		EntityManager manager = emf.createEntityManager();
		EntityTransaction tx = manager.getTransaction();
		tx.begin();
		String jpql = "delete from CartBean where pName=:pName";
		Query query = manager.createQuery(jpql);
		query.setParameter("pName", pName);
		query.executeUpdate();
		System.out.println("PRODUCT IS DELETED FROM THE CART");
		tx.commit();

	}

	@Override
	public void sendRequest(int uId) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("medicine");
		EntityManager entityManager = emf.createEntityManager();
		EntityTransaction tx = entityManager.getTransaction();

		String emailId = null;
		String jpql = "from UserBean where uId=:uId";
		Query query = entityManager.createQuery(jpql);
		query.setParameter("uId", uId);
		List<UserBean> list = query.getResultList();
		for (UserBean li : list) {
			emailId = li.getEmailId();

		}
		Scanner scan = new Scanner(System.in);
		System.out.println("ENTER THE MESSAGE TO BE SENT");
		String message = scan.nextLine();
		RequestBean bean = new RequestBean();
		bean.setuId(uId);
		bean.setEmailId(emailId);
		bean.setMsgReq(message);
		tx.begin();
		entityManager.persist(bean);
		tx.commit();
		if (bean != null) {
			System.out.println("MESSAGE SENT SUCCESSFULLY");
		}

	}

	@Override
	public void seeReply(int uId) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("medicine");
		EntityManager entityManager = emf.createEntityManager();
		String jpql = "from ReplyBean where uId=:uId";
		Query query = entityManager.createQuery(jpql);
		query.setParameter("uId", uId);

		List<ReplyBean> list = query.getResultList();
		for (ReplyBean li : list) {
			System.out.println("REPLY FROM USER IS" + li.getMsgReply());

		}

	}

}
