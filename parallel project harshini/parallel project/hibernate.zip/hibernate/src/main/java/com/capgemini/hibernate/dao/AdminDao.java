package com.capgemini.hibernate.dao;

import com.capgemini.hibernate.beans.AdminBean;

public interface AdminDao {
	public AdminBean adminLogin(String emailId, String password);
	public void insertProduct(String pCategory, int pId, String pName, Double pPrice, int pQuantity);

	public void deleteProduct(int pId);

	public void updateProduct(int pId);
	public void deleteUser(int uId);
	
	public void sendReply();
	public void seeRequest();

}
