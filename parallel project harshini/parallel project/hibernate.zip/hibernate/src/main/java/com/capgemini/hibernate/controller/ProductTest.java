package com.capgemini.hibernate.controller;

import java.util.List;

import com.capgemini.hibernate.beans.ProductBean;
import com.capgemini.hibernate.dao.Dao;
import com.capgemini.hibernate.factory.Factory;



public class ProductTest {
	public static void product() {
		Dao product = Factory.getDAOImplInstance();

		List<ProductBean> list = product.getProducts();

		if (list != null) {
			for (ProductBean user : list) {
				System.out.println(user.getpId());
				System.out.println(user.getpCategory());
				System.out.println(user.getpName());
				System.out.println(user.getpPrice());
				System.out.println(user.getpQuantity());
			}
		} else {
			System.out.println("Something Went Wrong...");
		}
	}

}
