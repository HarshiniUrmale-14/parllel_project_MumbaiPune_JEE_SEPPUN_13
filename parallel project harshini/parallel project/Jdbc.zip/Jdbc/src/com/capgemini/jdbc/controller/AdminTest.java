package com.capgemini.jdbc.controller;

import java.util.List;
import java.util.Scanner;

import com.capgemini.jdbc.bean.ProductBean;
import com.capgemini.jdbc.dao.AdminDao;
import com.capgemini.jdbc.dao.Dao;
import com.capgemini.jdbc.factory.Factory;

public class AdminTest {
	public static void admin() {
		Dao dao1 = Factory.getDAOImplInstance();
		AdminDao dao=Factory.getAdminDAOImplInstance();
		Scanner scan = new Scanner(System.in);
		System.out.println("ENTER THE EMAIL");
		String b = scan.nextLine();
		System.out.println("ENTER THE PASSWORD");
		String c = scan.nextLine();
		int s = dao.adminLogin(b, c);
		while (s != 0) {
			System.out.println("ENTER 1 TO VIEW THE PRODUCT ");
			System.out.println("ENTER 2 TO ADD THE PRODUCT ");
			System.out.println("ENTER 3 TO UPDATE THE PRODUCT ");
			System.out.println("ENTER 4 TO DELETE THE PRODUCT ");
			System.out.println("ENTER 5 TO DELETE THE USER");
			System.out.println("ENTER 6 TO SEE THE MESSAGE FROM USER");
			System.out.println("ENTER 7 TO GIVE REPLY TO USER");
			System.out.println("ENTER 8 TO LOGOUT");
			int btn = Integer.parseInt(scan.nextLine());
			switch (btn) {
			case 1: {
				System.out.println("HERE ARE THE PRODUCTS");
				List<ProductBean> list = dao1.getProducts();
				if (list != null) {
					for (ProductBean user : list) {
						System.out.println(user);
					}
				} else {
					System.out.println("SOMETHING WENT WRONG");

				}
				break;
			}
			case 2: {
				System.out.println(" ENTER THE PRODUCT CATEGORY");
				String category = scan.nextLine();
				System.out.println("ENTER THE PRODUCT ID ");
				int id = Integer.parseInt(scan.nextLine());
				System.out.println("ENTER THE PRODUCT NAME ");
				String name = scan.nextLine();
				System.out.println("ENTER THE PRODUCT PRICE ");
				Double price = Double.parseDouble(scan.nextLine());
				System.out.println("ENTER THE PRODUCT QUANTITY AVAILABLE");
				int quantity = Integer.parseInt(scan.nextLine());

				int m = dao.insertProduct(category, id, name, price, quantity);
				if (m != 0) {
					System.out.println("DATA INSERTED");
				}
				break;

			}

			case 3: {
				System.out.println("ENTER THE ID OF PRODUCT TO BE UPDATED");
				int id = Integer.parseInt(scan.nextLine());

				dao.updateProduct(id);

				break;
			}//end of case 3

			case 4: {
				System.out.println("ENTER THE PRODUCT ID ");
				int id = Integer.parseInt(scan.nextLine());
				int d = dao.deleteProduct(id);
				if (d != 0) {
					System.out.println("DATA DELETED");
				}
				break;
			}//end of case 4
			case 5: {
				System.out.println("ENTER THE ID OF USER TO BE DELETED");
				int id = Integer.parseInt(scan.nextLine());
				int r = dao.deleteUser(id);
				if (r != 0) {
					System.out.println("USER DELETED");
				}
				break;
			}
			case 6: {
				dao.seeRequest();
				break;
			}
			case 7: {
					dao.sendReply();	
					break;
			}
			
			case 8: {
				System.out.println("YOU ARE LOGGED OUT");
				System.exit(0);
				break;
			}
			}

		}
	}
}
