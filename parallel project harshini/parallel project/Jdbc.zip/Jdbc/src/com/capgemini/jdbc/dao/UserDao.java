package com.capgemini.jdbc.dao;

public interface UserDao {
	public int userLogin(String emailId, String password);

	public void registration(String emailId, String password,String mobileNo);

	public void updateUser(int uId);

	public int addToCart(int uId);

	public void payment(int uId);

	public int deleteFromCart(String pName);

	public void sendRequest(int uId);
	public void seeReply(int uId);


}
