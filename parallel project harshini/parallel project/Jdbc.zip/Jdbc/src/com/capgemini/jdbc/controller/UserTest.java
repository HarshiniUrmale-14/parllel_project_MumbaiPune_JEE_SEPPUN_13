package com.capgemini.jdbc.controller;

import java.util.List;
import java.util.Scanner;

import com.capgemini.jdbc.bean.ProductBean;
import com.capgemini.jdbc.bean.UserBean;
import com.capgemini.jdbc.dao.Dao;
import com.capgemini.jdbc.dao.UserDao;
import com.capgemini.jdbc.factory.Factory;
import com.capgemini.jdbc.validation.ValidationDao;

public class UserTest {
	public static void user() {

		Scanner scan = new Scanner(System.in);
		Dao dao1 = Factory.getDAOImplInstance();
		UserDao dao = Factory.getUserDAOImplInstance();
		ValidationDao vali = Factory.getValImplInstance();
		UserBean userBean = new UserBean();
		System.out.println("ENTER THE EMAIL");
		String m = scan.nextLine();
		
		System.out.println("ENTER THE PASSWORD");
		String c = scan.nextLine();
		

		int s = dao.userLogin(m, c);
		while (s != 0) {
			System.out.println("ENTER 1 TO VIEW THE PRODUCTS");
			System.out.println("ENTER 2 TO ADD PRODUCT TO THE CART");
			System.out.println("ENTER 3 TO DELETE PRODUCT FROM CART");
			System.out.println("ENTER 4 TO MAKE PAYMENT");
			System.out.println("ENTER 5 TO UPDATE THE PROFILE OF USER");
			System.out.println("ENTER 6 TO SEND THE MESSAGE TO ADMINISTRATOR");
			System.out.println("ENTER 7 TO SEE THE REPLY FROM ADMINISTRATOR");
			System.out.println("ENTER 8 TO LOGOUT");
			int btn = Integer.parseInt(scan.nextLine());
			switch (btn) {
			case 1: {
				List<ProductBean> list = dao1.getProducts();
				if (list != null) {
					for (ProductBean user : list) {
						System.out.println(user);
					}
				} else {
					System.out.println("SOMETHING WENT WRONG");
				}
				break;
			}

			case 2: {
				System.out.println("ADD THE PRODUCTS TO THE CART");
				int w = dao.addToCart(s);
				if (w != 0) {
					System.out.println("DATA SUCCESSFULLY ADDED TO THE CART");
				}
				System.out.println("ENTER 1 TO DELETE PRODUCT FROM THE CART");
				System.out.println("ENTER 2 TO MAKE PAYMENT");
				int bt = Integer.parseInt(scan.nextLine());
				if (bt == 1) {
					System.out.println("ENTER THE PRODUCT NAME TO BE DELETED");
					String e = scan.nextLine();
					int q = dao.deleteFromCart(e);
					if (q != 0) {
						System.out.println("PRODUCT IS DELETED FROM THE CART");
					}
				} else {
					System.out.println("YOUR PAYMENT IS");
					dao.payment(s);
				}

				break;
			}
			case 3:{
				System.out.println("ENTER THE PRODUCT NAME TO BE DELETED");
				String e = scan.nextLine();
				int q = dao.deleteFromCart(e);
				break;
			}
			case 4:{
				System.out.println("YOUR PAYMENT IS");
				dao.payment(s);
				break;
			}
			case 5: {
				System.out.println("UPDATE THE PROFILE");
				dao.updateUser(s);
				break;
			}
			case 6: {

				dao.sendRequest(s);
				break;

			}
			case 7: {

				dao.seeReply(s);
				break;

			}
			case 8: {
				System.out.println("YOU ARE LOGGED OUT");
				System.exit(0);
				break;
			}

			}

		}
	}
}
