package com.capgemini.jdbc.dao;

import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;
import java.util.Scanner;

public class UserDaoImpl implements UserDao {
	FileReader reader;

	Properties prop;
	Scanner scan = new Scanner(System.in);

	public UserDaoImpl() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			reader = new FileReader("db.properties");
			prop = new Properties();
			prop.load(reader);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public int userLogin(String emailId, String password) {
		int uid = 0;
		try (Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
				prop.getProperty("password"));
				PreparedStatement pstmt = conn.prepareStatement(prop.getProperty("query1"))) {

			pstmt.setString(1, emailId);
			pstmt.setString(2, password);

			try (ResultSet res = pstmt.executeQuery()) {
				if (res.next()) {
					System.out.println("login successfully");
					System.out.println("id =" + res.getInt(1));
					uid = res.getInt(1);

				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return uid;
	}
		
	

	@Override
	public void registration(String emailId, String password,String mobileNo) {
		

		try (Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
				prop.getProperty("password"));
				PreparedStatement pstmt = conn.prepareStatement(prop.getProperty("query10"))) {

			pstmt.setString(1, emailId);
			pstmt.setString(2, password);
			pstmt.setString(3, mobileNo);

			 int count = pstmt.executeUpdate();
			 if(count!=0) {
				 System.out.println("REGISTRATION DONE SUCCESSFULLY");
			 }

		} catch (Exception e) {
			e.printStackTrace();
		}

	
		
	}

	@Override
	public void updateUser(int uId) {
		System.out.println("ENTER 1 TO CHANGE THE EMAIL");
		System.out.println("ENTER 2 TO CHANGE THE PASSWORD");
		System.out.println("ENTER 3 TO CHANGE THE PHONENO");
		int button = Integer.parseInt(scan.nextLine());
		if (button == 1) {
			System.out.println("ENTER EMAILID");
			String emailId = scan.nextLine();
			try (Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
					prop.getProperty("password"));
					PreparedStatement pstmt = conn.prepareStatement(prop.getProperty("query11"))) {

				pstmt.setString(1, emailId);
				pstmt.setInt(2, uId);

				int count = pstmt.executeUpdate();
				if (count > 0) {
					System.out.println("USER PROFILE UPDATED");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

		} else if (button == 2) {
			System.out.println("ENTER PASSWORD");
			String password = scan.nextLine();
			try (Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
					prop.getProperty("password"));
					PreparedStatement pstmt = conn.prepareStatement(prop.getProperty("query12"))) {

				pstmt.setString(1, password);
				pstmt.setInt(2, uId);

				int count = pstmt.executeUpdate();
				if (count > 0) {
					System.out.println("USER PROFILE UPDATED");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

		}else if(button==3) {
			System.out.println("ENTER THE PHONE NO");
			String mobileNo =scan.nextLine();
			try (Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
					prop.getProperty("password"));
					PreparedStatement pstmt = conn.prepareStatement(prop.getProperty("query24"))) {

				pstmt.setString(1,mobileNo );
				pstmt.setInt(2, uId);

				int count = pstmt.executeUpdate();
				if (count > 0) {
					System.out.println("USER PROFILE UPDATED");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
		
	}

	@Override
	public int addToCart(int uId) {
		String emailId = null;
		String pName = null;
		String pCategory = null;
		int pId = 0;
		double pPrice = 0;
		try (Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
				prop.getProperty("password"));
				PreparedStatement pstmt = conn.prepareStatement(prop.getProperty("query14"))) {

			pstmt.setInt(1, uId);
			ResultSet res = pstmt.executeQuery();
			if (res.next()) {
				System.out.println("emailid" + res.getString(1));
				System.out.println("uid" + uId);
				emailId = res.getString(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("ENTER THE PRODUCT NAME TO BE ADDED TO THE CART");
		pName = scan.nextLine();
		try (Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
				prop.getProperty("password"));
				PreparedStatement pstmt = conn.prepareStatement(prop.getProperty("query15"))) {

			pstmt.setString(1, pName);
			ResultSet res1 = pstmt.executeQuery();
			if (res1.next()) {
				System.out.println("pcategory" + res1.getString(1));
				System.out.println("pid" + res1.getInt(2));
				System.out.println("pprice" + res1.getDouble(3));
				pCategory = res1.getString(1);
				pId = res1.getInt(2);
				pPrice = res1.getDouble(3);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		int count = 0;
		System.out.println("ENTER THE NO QUANTITY OF THE SELECTED PRODUCT");
		int quantity = Integer.parseInt(scan.nextLine());
		try (Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
				prop.getProperty("password"));
				PreparedStatement pstmt1 = conn.prepareStatement(prop.getProperty("query16"))) {

			// ProductBean product = new ProductBean();
			pstmt1.setInt(1, uId);
			pstmt1.setInt(2, pId);
			pstmt1.setString(3, emailId);
			pstmt1.setString(4, pCategory);
			pstmt1.setString(5, pName);
			pstmt1.setDouble(6, pPrice);
			pstmt1.setInt(7, quantity);
			count = pstmt1.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return count;
		
		
	}

	@Override
	public void payment(int uId) {
		int count = 0;

		try (Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
				prop.getProperty("password"));
				PreparedStatement pstmt = conn.prepareStatement(prop.getProperty("query18"))) {

			pstmt.setInt(1, uId);

			ResultSet res = pstmt.executeQuery();
			if (res.next()) {
				System.out.println("total price is" + res.getDouble(1));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public int deleteFromCart(String pName) {
		int count = 0;

		try (Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
				prop.getProperty("password"));
				PreparedStatement pstmt = conn.prepareStatement(prop.getProperty("query17"))) {
			pstmt.setString(1, pName);

			count = pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return count;

		
	}

	@Override
	public void sendRequest(int uId) {
		String getEmailId = null;
		String msg = null;
		int count = 0;
		try (Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
				prop.getProperty("password"));
				PreparedStatement pstmt = conn.prepareStatement(prop.getProperty("query19"))) {

			pstmt.setInt(1, uId);

			try (ResultSet res = pstmt.executeQuery()) {
				if (res.next()) {
					System.out.println("EMAILID IS" + res.getString(1));
					System.out.println("USER ID IS" + uId);
					getEmailId = res.getString(1);
					

				}
				System.out.println("ENTER THE MESSAGE TO BE SENT");
				msg = scan.nextLine();
				try (Connection conn1 = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
						prop.getProperty("password"));
						PreparedStatement pstmt1 = conn1.prepareStatement(prop.getProperty("query20"))) {
					pstmt1.setInt(1, uId);
					pstmt1.setString(2, getEmailId);
					pstmt1.setString(3, msg);

					count = pstmt1.executeUpdate();
					if (count > 0) {
						System.out.println("DATA IS INSERTED");
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		
	}

	@Override
	public void seeReply(int uId) {
		try (Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
				prop.getProperty("password"));
				PreparedStatement pstmt = conn.prepareStatement(prop.getProperty("query21"))) {

			pstmt.setInt(1, uId);

			try (ResultSet res = pstmt.executeQuery()) {

				if (res.next()) {
					System.out.println("MESSAGE IS" + res.getString(1));

				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
