package com.capgemini.jdbc.dao;

public interface AdminDao {
	public int adminLogin(String emailId, String password);
	public int insertProduct(String pCategory, int pId, String pName, Double pPrice, int pQuantity);

	public int deleteProduct(int pId);

	public void updateProduct(int pId);
	public int deleteUser(int uId);
	
	public void sendReply();
	public void seeRequest();
}
