package com.capgemini.jdbc.bean;

public class ReplyBean {
	private int replyId;
	private int uId;
	private String emailId;
	private String msgReply;

	public int getReplyId() {
		return replyId;
	}

	public void setReplyId(int replyId) {
		this.replyId = replyId;
	}

	public int getuId() {
		return uId;
	}

	public void setuId(int uId) {
		this.uId = uId;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getMsgReply() {
		return msgReply;
	}

	public void setMsgReply(String msgReply) {
		this.msgReply = msgReply;
	}

}
