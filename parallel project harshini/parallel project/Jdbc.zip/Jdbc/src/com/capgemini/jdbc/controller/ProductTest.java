package com.capgemini.jdbc.controller;

import java.util.List;

import com.capgemini.jdbc.bean.ProductBean;
import com.capgemini.jdbc.dao.Dao;
import com.capgemini.jdbc.factory.Factory;

public class ProductTest {
	public static void product() {
		Dao product = Factory.getDAOImplInstance();

		List<ProductBean> list = product.getProducts();

		if (list != null) {
			for (ProductBean user : list) {
				System.out.println(user.getpCategory());
				System.out.println(user.getpId());
				System.out.println(user.getpName());
				System.out.println(user.getpPrice());
				System.out.println(user.getpQuantity());
			}
		} else {
			System.out.println("Something Went Wrong...");
		}
	}

}
