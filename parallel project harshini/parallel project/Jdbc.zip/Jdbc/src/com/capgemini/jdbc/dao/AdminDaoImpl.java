package com.capgemini.jdbc.dao;

import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Properties;
import java.util.Scanner;

public class AdminDaoImpl  implements AdminDao{
	FileReader reader;

	Properties prop;
	Scanner scan = new Scanner(System.in);

	public AdminDaoImpl() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			reader = new FileReader("db.properties");
			prop = new Properties();
			prop.load(reader);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public int adminLogin(String emailId, String password) {
		int id = 0;
		try (Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
				prop.getProperty("password"));
				PreparedStatement pstmt = conn.prepareStatement(prop.getProperty("query2"))) {

			pstmt.setString(1, emailId);
			pstmt.setString(2, password);

			try (ResultSet res = pstmt.executeQuery()) {
				if (res.next()) {
					System.out.println("login successfully");
					System.out.println("id =" + res.getInt(1));
					id = res.getInt(1);

				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return id;
			}

	@Override
	public int insertProduct(String pCategory, int pId, String pName, Double pPrice, int pQuantity) {
		int count = 0;
		try (Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
				prop.getProperty("password"));
				PreparedStatement pstmt = conn.prepareStatement(prop.getProperty("query3"))) {

			
			pstmt.setString(1, pCategory);
			pstmt.setInt(2, pId);
			pstmt.setString(3, pName);
			pstmt.setDouble(4, pPrice);
			pstmt.setInt(5, pQuantity);
			count = pstmt.executeUpdate();

			if (count > 0) {
				System.out.println("data inserted");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return count;
		
	}

	@Override
	public int deleteProduct(int pId) {
		int count = 0;

		try (Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
				prop.getProperty("password"));
				PreparedStatement pstmt = conn.prepareStatement(prop.getProperty("query4"))) {
			pstmt.setInt(1, pId);

			count = pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return count;
		
	}

	@Override
	public void updateProduct(int pId) {

		System.out.println("ENTER 1 TO UPDATE THE CATEGORY");
		System.out.println("ENTER 2 TO UPDATE THE NAME");
		System.out.println("ENTER 3 TO UPDATE THE PRICE");
		System.out.println("enter 4 TO UPDATE THE QUANTITY ");
		int button = Integer.parseInt(scan.nextLine());
		if (button == 1) {
			System.out.println("ENTER CATEGORY");
			String category = scan.nextLine();
			try (Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
					prop.getProperty("password"));
					PreparedStatement pstmt = conn.prepareStatement(prop.getProperty("query5"))) {

				pstmt.setString(1, category);
				pstmt.setInt(2, pId);
				int count = pstmt.executeUpdate();
				if (count > 0) {
					System.out.println("data updated........");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else if (button == 2) {
			System.out.println("ENTER NAME");
			String name = scan.nextLine();
			try (Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
					prop.getProperty("password"));
					PreparedStatement pstmt = conn.prepareStatement(prop.getProperty("query6"))) {

				pstmt.setString(1, name);
				pstmt.setInt(2, pId);
				int count = pstmt.executeUpdate();
				if (count > 0) {
					System.out.println("data updated........");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else if (button == 3) {
			System.out.println("ENTER PRICE");
			double price = Double.parseDouble(scan.nextLine());

			try (Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
					prop.getProperty("password"));
					PreparedStatement pstmt = conn.prepareStatement(prop.getProperty("query7"))) {
				pstmt.setDouble(1, price);
				pstmt.setInt(2, pId);
				int count = pstmt.executeUpdate();
				if (count > 0) {
					System.out.println("data updated........");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else if (button == 4) {
			System.out.println("ENTER QUANTITY");
			String quantity = scan.nextLine();

			try (Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
					prop.getProperty("password"));
					PreparedStatement pstmt = conn.prepareStatement(prop.getProperty("query8"))) {

				pstmt.setString(1, quantity);
				pstmt.setInt(2, pId);
				int count = pstmt.executeUpdate();
				if (count > 0) {
					System.out.println("data updated........");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
	}

	@Override
	public int deleteUser(int uId) {int count = 0;

	try (Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
			prop.getProperty("password"));
			PreparedStatement pstmt = conn.prepareStatement(prop.getProperty("query13"))) {
		pstmt.setInt(1, uId);

		count = pstmt.executeUpdate();

	} catch (Exception e) {
		e.printStackTrace();
	}

	return count;
		
	}

	@Override
	public void sendReply() {
		String getEmailId = null;
		String msg = null;
		
		int count = 0;
		try (Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
				prop.getProperty("password"));
				PreparedStatement pstmt = conn.prepareStatement(prop.getProperty("query19"))) {

		System.out.println("ENTER THE USER ID");
		int id=Integer.parseInt(scan.nextLine());
		pstmt.setInt(1, id);
		

			try (ResultSet res = pstmt.executeQuery()) {
			while(res.next()) {
					System.out.println("EMAILID IS" + res.getString(1));
					System.out.println("USER ID IS" + id);
				
					getEmailId = res.getString(1);
					

				}
				System.out.println("ENTER THE MESSAGE TO BE SENT");
				msg = scan.nextLine();
				try (Connection conn1 = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
						prop.getProperty("password"));
						PreparedStatement pstmt1 = conn1.prepareStatement(prop.getProperty("query23"))) {
					pstmt1.setInt(1, id);
					pstmt1.setString(2, getEmailId);
					pstmt1.setString(3, msg);

					count = pstmt1.executeUpdate();
					if (count > 0) {
						System.out.println("DATA IS INSERTED");
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		

	}

		
	

	@Override
	public void seeRequest() {
		try (Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
				prop.getProperty("password")); Statement stmt = conn.createStatement()) {

			try (ResultSet res = stmt.executeQuery(prop.getProperty("query22"))) {
				while (res.next()) {
					System.out.println("MESSAGE ID IS"+res.getInt(1));
					System.out.println("USER ID IS"+res.getInt(2));
					System.out.println("EMAILID IS"+res.getString(3));
					System.out.println("MESSAGE  IS"+res.getString(4));

				}

			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		
	}

}
