package com.capgemini.jdbc.bean;

public class RequestBean {
	private int mgsId;
	private int uId;
	private String emailId;
	private String msgReq;

	public int getMgsId() {
		return mgsId;
	}

	public void setMgsId(int mgsId) {
		this.mgsId = mgsId;
	}

	public int getuId() {
		return uId;
	}

	public void setuId(int uId) {
		this.uId = uId;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getMsgReq() {
		return msgReq;
	}

	public void setMsgReq(String msgReq) {
		this.msgReq = msgReq;
	}

}
