package com.capgemini.springmvc.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "admin_reply")
public class ReplyBean {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "replyid")
	private int replyId;
	@Column(name = "uid")
	private int uId;
	@Column(name = "emailid")
	private String emailId;
	@Column(name = "msgreply")
	private String msgReply;

	public int getReplyId() {
		return replyId;
	}

	public void setReplyId(int replyId) {
		this.replyId = replyId;
	}

	public int getuId() {
		return uId;
	}

	public void setuId(int uId) {
		this.uId = uId;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getMsgReply() {
		return msgReply;
	}

	public void setMsgReply(String msgReply) {
		this.msgReply = msgReply;
	}

}
