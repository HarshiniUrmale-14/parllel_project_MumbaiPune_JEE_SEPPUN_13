package com.capgemini.springmvc.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "user_req")
public class RequestBean {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "msgid")
	private int mgsId;
	@Column(name = "uid")
	private int uId;
	@Column(name = "emailid")
	private String emailId;
	@Column(name = "msgreq")
	private String msgReq;

	public int getMgsId() {
		return mgsId;
	}

	public void setMgsId(int mgsId) {
		this.mgsId = mgsId;
	}

	public int getuId() {
		return uId;
	}

	public void setuId(int uId) {
		this.uId = uId;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getMsgReq() {
		return msgReq;
	}

	public void setMsgReq(String msgReq) {
		this.msgReq = msgReq;
	}

}
